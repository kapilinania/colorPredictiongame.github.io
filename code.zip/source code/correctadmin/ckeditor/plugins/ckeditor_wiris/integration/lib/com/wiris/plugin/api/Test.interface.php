<?php

interface com_wiris_plugin_api_Test {
	function getTestPage();
}
